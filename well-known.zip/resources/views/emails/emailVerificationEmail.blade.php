<h1>Email Verification</h1>
Click the link :
<a href="{{ route('user.verify', $token) }}">Click Here</a>
