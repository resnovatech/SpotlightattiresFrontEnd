<h1>{{ trans('main.Reset_Password_Mail')}}</h1>

{{ trans('main.v_e1')}}:
<a href="{{ route('password_reset_page', $id) }}">{{ trans('main.click_here')}}</a>
