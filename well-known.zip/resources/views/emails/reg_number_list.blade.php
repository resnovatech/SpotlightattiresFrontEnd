<h1>Apply For NGO Application Submitted</h1>

Your Registration Number:{{ $token }}.

