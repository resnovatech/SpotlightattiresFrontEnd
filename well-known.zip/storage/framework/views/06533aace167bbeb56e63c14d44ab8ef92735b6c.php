<?php $__env->startSection('title'); ?>
Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<main class="main__content_wrapper">

    <!-- Start breadcrumb section -->
    
    <!-- End breadcrumb section -->

    <!-- cart section start -->
    <section class="cart__section section--padding">
        <div class="container-fluid">
            <div class="cart__section--inner">

                    <h2 class="cart__title mb-40">Shopping Cart</h2>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="cart__table">
                                <table class="cart__table--inner">
                                    <thead class="cart__table--header">
                                        <tr class="cart__table--header__items">
                                            <th class="cart__table--header__list">Product</th>
                                            <th class="cart__table--header__list">Price</th>
                                            <th class="cart__table--header__list">Quantity</th>
                                            <th class="cart__table--header__list">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody class="cart__table--body">
                                    <?php $__currentLoopData = $cartCollection1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="cart__table--body__items">
                                            <td class="cart__table--body__list">
                                                <div class="cart__product d-flex align-items-center">
                                                    <a href="<?php echo e(route('cart_clear_single_data',$item->id)); ?>" class="cart__remove--btn" aria-label="search button" type="button">
                                                        <svg fill="currentColor" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" width="16px" height="16px"><path d="M 4.7070312 3.2929688 L 3.2929688 4.7070312 L 10.585938 12 L 3.2929688 19.292969 L 4.7070312 20.707031 L 12 13.414062 L 19.292969 20.707031 L 20.707031 19.292969 L 13.414062 12 L 20.707031 4.7070312 L 19.292969 3.2929688 L 12 10.585938 L 4.7070312 3.2929688 z"/></svg>
                                                    </a>
                                                    <div class="cart__thumbnail">
                                                        <a href="#"><img class="border-radius-5" src="<?php echo e($url_name); ?><?php echo e($item->attributes->image); ?>" alt="cart-product"></a>
                                                    </div>
                                                    <div class="cart__content">
                                                        <h4 class="cart__content--title"><a href="#">  <?php echo e($item->name); ?></a></h4>

                                                    </div>
                                                </div>
                                            </td>
                                            <td class="cart__table--body__list">
                                                <span class="cart__price">৳ <?php echo e($item->price); ?></span>
                                            </td>
                                            <td class="cart__table--body__list">
                                            <form method="get" action="<?php echo e(route('cart_update')); ?>">

                                                                                                        <input type="hidden" class="" name="id" value="<?php echo e($item->id); ?>"/>

                                                <div class="quantity__box">
                                                    <button type="button" class="quantity__value quickview__value--quantity decrease" aria-label="quantity value" value="Decrease Value">-</button>
                                                    <label>
                                                        <input type="number" class="quantity__number quickview__value--number" name="quantity" value="<?php echo e($item->quantity); ?>" data-counter/>
                                                    </label>
                                                    <button type="button" class="quantity__value quickview__value--quantity increase" aria-label="quantity value" value="Increase Value">+</button>
                                                </div>

                                                <button type="submit" class="btn btn-primary btn-sm">update</button>
                                                </form>
                                            </td>
                                            <td class="cart__table--body__list">
                                                <span class="cart__price end">৳ <?php echo e($item->price*$item->quantity); ?></span>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <div class="continue__shopping d-flex justify-content-between">
                                    <a class="continue__shopping--link" href="<?php echo e(route('index')); ?>">Continue shopping</a>
                                    <a class="continue__shopping--clear" href="<?php echo e(route('cart_clear_all_data')); ?>">Clear Cart</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="cart__summary border-radius-10">


                                <div class="cart__summary--total mb-20">
                                    <table class="cart__summary--total__table">
                                        <tbody>

                                            <tr class="cart__summary--total__list">
                                                <td class="cart__summary--total__title text-left">GRAND TOTAL</td>
                                                <td class="cart__summary--amount text-right"> ৳  <?php echo e(\Cart::getTotal()); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="cart__summary--footer">

                                    <ul class="d-flex justify-content-between">
                                        
                                        <li><a class="cart__summary--footer__btn primary__btn checkout" href="<?php echo e(route('check_out_from_cart')); ?>">Check Out</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </section>
    <!-- cart section end -->

    <!-- Start product section -->
    <section class="product__section section--padding pt-0">
        <div class="container-fluid">
            <div class="section__heading text-center mb-50">
                <h2 class="section__heading--maintitle">New Products</h2>
            </div>
            <div class="product__section--inner product__swiper--activation swiper">
                <div class="swiper-wrapper">

                      <?php

$get_product_name = DB::table('assaign_categories')->where('cat_name','new_product')->select('product_name')->get();

$convert_name_title = $get_product_name->implode("product_name", " ");


$separated_data_title = explode(" ", $convert_name_title);


                        $feature_product_list23 = DB::table('main_products')
                        ->whereIn('slug',$separated_data_title)->latest()->limit('10')->get();






                            ?>
                            <?php $__currentLoopData = $feature_product_list23; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_feature_product_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                         $feature_image_one =DB::table('feature_product_images')->where('product_name',$all_feature_product_list->id)->orderBy('id','desc')->value('filename');
                         $feature_image_two =DB::table('feature_product_images')->where('product_name',$all_feature_product_list->id)->orderBy('id','asc')->value('filename');

                            ?>
                    <div class="swiper-slide">
                        <div class="product__items ">
                            <div class="product__items--thumbnail">
                                <a class="product__items--link" href="<?php echo e(route('productDetail',$all_feature_product_list->slug)); ?>">
                                    <img class="product__items--img product__primary--img" src="<?php echo e($url_name); ?><?php echo e($all_feature_product_list->front_image); ?>" alt="product-img">
                                    <img class="product__items--img product__secondary--img" src="<?php echo e($url_name); ?><?php echo e($all_feature_product_list->back_image); ?>" alt="product-img">
                                </a>
                                <div class="product__badge">
                                    <span class="product__badge--items sale">Sale</span>
                                </div>
                            </div>
                            <div class="product__items--content">
                                <span class="product__items--content__subtitle"><?php echo e($all_feature_product_list->cat_name); ?></span>
                                <h3 class="product__items--content__title h4"><a href="<?php echo e(route('productDetail',$all_feature_product_list->slug)); ?>"><?php echo e($all_feature_product_list->product_name); ?></a></h3>
                                <div class="product__items--price">
                                    <span class="current__price">৳ <?php echo e($all_feature_product_list->selling_price); ?></span>

                                </div>

                                <ul class="product__items--action d-flex">
                                    <li class="product__items--action__list">
                                        <a class="product__items--action__btn add__to--cart" href="<?php echo e(route('cart_post',$all_feature_product_list->id)); ?>">
                                            <svg class="product__items--action__btn--svg" xmlns="http://www.w3.org/2000/svg" width="22.51" height="20.443" viewBox="0 0 14.706 13.534">
                                                <g transform="translate(0 0)">
                                                  <g>
                                                    <path data-name="Path 16787" d="M4.738,472.271h7.814a.434.434,0,0,0,.414-.328l1.723-6.316a.466.466,0,0,0-.071-.4.424.424,0,0,0-.344-.179H3.745L3.437,463.6a.435.435,0,0,0-.421-.353H.431a.451.451,0,0,0,0,.9h2.24c.054.257,1.474,6.946,1.555,7.33a1.36,1.36,0,0,0-.779,1.242,1.326,1.326,0,0,0,1.293,1.354h7.812a.452.452,0,0,0,0-.9H4.74a.451.451,0,0,1,0-.9Zm8.966-6.317-1.477,5.414H5.085l-1.149-5.414Z" transform="translate(0 -463.248)" fill="currentColor"></path>
                                                    <path data-name="Path 16788" d="M5.5,478.8a1.294,1.294,0,1,0,1.293-1.353A1.325,1.325,0,0,0,5.5,478.8Zm1.293-.451a.452.452,0,1,1-.431.451A.442.442,0,0,1,6.793,478.352Z" transform="translate(-1.191 -466.622)" fill="currentColor"></path>
                                                    <path data-name="Path 16789" d="M13.273,478.8a1.294,1.294,0,1,0,1.293-1.353A1.325,1.325,0,0,0,13.273,478.8Zm1.293-.451a.452.452,0,1,1-.431.451A.442.442,0,0,1,14.566,478.352Z" transform="translate(-2.875 -466.622)" fill="currentColor"></path>
                                                  </g>
                                                </g>
                                            </svg>
                                            <span class="add__to--cart__text"> + Add to cart</span>
                                        </a>
                                    </li>
                                    <li class="product__items--action__list" data-detailp = "<?php echo e($all_feature_product_list->product_detail); ?>" data-pricep = "<?php echo e($all_feature_product_list->selling_price); ?>" data-namep = "<?php echo e($all_feature_product_list->product_name); ?>" id="qq_view<?php echo e($all_feature_product_list->id); ?>">
                                        <a class="product__items--action__btn" data-open="modal1" href="javascript:void(0)">
                                            <svg class="product__items--action__btn--svg" xmlns="http://www.w3.org/2000/svg"  width="25.51" height="23.443" viewBox="0 0 512 512"><path d="M255.66 112c-77.94 0-157.89 45.11-220.83 135.33a16 16 0 00-.27 17.77C82.92 340.8 161.8 400 255.66 400c92.84 0 173.34-59.38 221.79-135.25a16.14 16.14 0 000-17.47C428.89 172.28 347.8 112 255.66 112z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><circle cx="256" cy="256" r="80" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/></svg>
                                            <span class="visually-hidden">Quick View</span>
                                        </a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
                <div class="swiper__nav--btn swiper-button-next"></div>
                <div class="swiper__nav--btn swiper-button-prev"></div>
            </div>
        </div>
    </section>
    <!-- End product section -->



</main>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_july_2022\htdocs\2023\new_ecommerce_march\resources\views/front/cartPage/index.blade.php ENDPATH**/ ?>