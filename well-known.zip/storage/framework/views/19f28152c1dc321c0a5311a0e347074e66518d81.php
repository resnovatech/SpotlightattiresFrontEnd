<h1>Email Verification</h1>
Click the link :
<a href="<?php echo e(route('user.verify_new', $token)); ?>">Click Here</a>
<?php /**PATH /home/nirrtjiu/demo.spotlightattires.com/resources/views/emails/emailVerificationEmail1.blade.php ENDPATH**/ ?>