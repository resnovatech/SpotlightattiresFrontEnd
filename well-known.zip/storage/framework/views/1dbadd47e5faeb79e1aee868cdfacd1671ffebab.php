<legend class="product__variant--title mb-8">Color :</legend>

<?php $__currentLoopData = $assaign_color_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$all_assaign_color_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php

$color_code =  DB::table('attribute_details')->where('name_list',$all_assaign_color_all->color_id)->value('name_code');

?>
<?php if(($key+1) == 1): ?>
                                        <input id="color-red<?php echo e($key+1); ?>" class="color" value="<?php echo e($all_assaign_color_all->color_id); ?>" name="color" type="radio" checked>
                                        <label class="variant__color--value red" for="color-red<?php echo e($key+1); ?>" title="Red" style="background-color: <?php echo e($color_code); ?>"></label>

                                        <?php else: ?>

                                        <input id="color-red<?php echo e($key+1); ?>" value="<?php echo e($all_assaign_color_all->color_id); ?>" name="color" type="radio" >
                                        <label class="variant__color--value red" for="color-red<?php echo e($key+1); ?>" title="Red" style="background-color: <?php echo e($color_code); ?>"></label>


                                        <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH E:\project_july_2022\htdocs\2023\new_ecommerce_march\resources\views/front/productPages/quick_view_data1.blade.php ENDPATH**/ ?>