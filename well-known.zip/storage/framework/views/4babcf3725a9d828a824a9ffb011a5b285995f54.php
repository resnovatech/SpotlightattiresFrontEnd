



<?php /**PATH /home/nirrtjiu/demo.spotlightattires.com/resources/views/front/productPages/quick_view_data3.blade.php ENDPATH**/ ?>