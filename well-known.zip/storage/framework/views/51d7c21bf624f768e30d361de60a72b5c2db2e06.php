<?php $__env->startSection('title'); ?>

Blog

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
<main class="main__content_wrapper">

    <!-- Start breadcrumb section -->
    
    <!-- End breadcrumb section -->

    <!-- Start blog section -->
    <section class="blog__section section--padding">
        <div class="container">
            <div class="section__heading text-center mb-50">
                <h2 class="section__heading--maintitle">From The Blog</h2>
            </div>
            <div class="blog__section--inner">
                <div class="row row-cols-lg-3 row-cols-md-2 row-cols-sm-2 row-cols-sm-u-2 row-cols-1 mb--n30">

<?php $__currentLoopData = $blog_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_blog_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php

                                     $ddd =$all_blog_list->date;
                                    ?>

                    <div class="col mb-30">
                        <div class="blog__items">
                            <div class="blog__thumbnail">
                                <a class="blog__thumbnail--link" href="<?php echo e(route('blog_view',$all_blog_list->title)); ?>"><img class="blog__thumbnail--img" src="<?php echo e($url_name); ?><?php echo e($all_blog_list->image); ?>" alt="blog-img"></a>
                            </div>
                            <div class="blog__content">
                                <span class="blog__content--meta"><?php echo e(date('F d, Y', strtotime($ddd))); ?></span>
                                <h3 class="blog__content--title"><a href="<?php echo e(route('blog_view',$all_blog_list->title)); ?>"><?php echo e($all_blog_list->title); ?></a></h3>
                                <a class="blog__content--btn primary__btn" href="<?php echo e(route('blog_view',$all_blog_list->title)); ?>">Read more </a>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="pagination__area bg__gray--color">

                </div>
            </div>
        </div>
    </section>
    <!-- End blog section -->

    <!-- Start shipping section -->
    <section class="shipping__section2 shipping__style3 section--padding pt-0">
        <div class="container">
            <div class="shipping__section2--inner shipping__style3--inner d-flex justify-content-between">
                <div class="shipping__items2 d-flex align-items-center">
                    <div class="shipping__items2--icon">
                        <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping1.png" alt="">
                    </div>
                    <div class="shipping__items2--content">
                        <h2 class="shipping__items2--content__title h3">Shipping</h2>
                        <p class="shipping__items2--content__desc">From handpicked sellers</p>
                    </div>
                </div>
                <div class="shipping__items2 d-flex align-items-center">
                    <div class="shipping__items2--icon">
                        <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping2.png" alt="">
                    </div>
                    <div class="shipping__items2--content">
                        <h2 class="shipping__items2--content__title h3">Payment</h2>
                        <p class="shipping__items2--content__desc">From handpicked sellers</p>
                    </div>
                </div>
                <div class="shipping__items2 d-flex align-items-center">
                    <div class="shipping__items2--icon">
                        <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping3.png" alt="">
                    </div>
                    <div class="shipping__items2--content">
                        <h2 class="shipping__items2--content__title h3">Return</h2>
                        <p class="shipping__items2--content__desc">From handpicked sellers</p>
                    </div>
                </div>
                <div class="shipping__items2 d-flex align-items-center">
                    <div class="shipping__items2--icon">
                        <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping4.png" alt="">
                    </div>
                    <div class="shipping__items2--content">
                        <h2 class="shipping__items2--content__title h3">Support</h2>
                        <p class="shipping__items2--content__desc">From handpicked sellers</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End shipping section -->
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nirrtjiu/demo.spotlightattires.com/resources/views/front/otherPage/blog.blade.php ENDPATH**/ ?>