<?php $__env->startSection('title'); ?>

Customer Dasboard

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
<main class="main__content_wrapper">

        
        <!-- End breadcrumb section -->

        <!-- my account section start -->
        <section class="my__account--section section--padding">
            <div class="container">
                <p class="account__welcome--text">Hello, <?php echo e(Auth::user()->name); ?> welcome to your dashboard!</p>
                <div class="my__account--section__inner border-radius-10 d-flex">
                    <div class="account__left--sidebar">
                        <h2 class="account__content--title h3 mb-20">My Profile</h2>
                        <ul class="account__menu">
                            <li class="account__menu--list active"><a href="my-account.html">Dashboard</a></li>

                            <li class="account__menu--list"><a href="<?php echo e(route('signout')); ?>">Log Out</a></li>
                        </ul>
                    </div>
                    <div class="account__wrapper">
                        <?php echo $__env->make('flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="account__content">
                        <h2 class="account__content--title h3 mb-20">Personal Info</h2>
                        <p><?php echo e(Auth::user()->name); ?></p>
                        <hr>
                        <?php

                        $get_all_address12_id = DB::table('delivary_addresses')
                        ->where('user_id',Auth::user()->id)->value('id');
                        
                        
                         $get_all_address12_first = DB::table('delivary_addresses')
                        ->where('user_id',Auth::user()->id)->value('first_name');
                        
                 $get_all_address12_last = DB::table('delivary_addresses')
                        ->where('user_id',Auth::user()->id)->value('last_name');
                        
                $get_all_address12_phone = DB::table('delivary_addresses')
                        ->where('user_id',Auth::user()->id)->value('phone');
                        
                        
            
            
              $get_all_address12_address = DB::table('delivary_addresses')
                        ->where('user_id',Auth::user()->id)->value('address');
    
    
       $get_all_address12_town = DB::table('delivary_addresses')
                        ->where('user_id',Auth::user()->id)->value('town');
                        
                        
                        

 ?>
<h2 class="account__content--title h3 mb-20">Delivery Address</h2>
<form method="post" action="<?php echo e(route('address_update_code')); ?>">
<?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($get_all_address12_id); ?>" name="id" />

    <p> First Name : <input type="text" class="checkout__discount--code__input--field border-radius-5" name="first_name" value="<?php echo e($get_all_address12_first); ?>" /> </p>
    <p> Last Name : <input type="text" class="checkout__discount--code__input--field border-radius-5" name="last_name" value="<?php echo e($get_all_address12_last); ?>" /> </p>

    <p> Phone : <input type="text" class="checkout__discount--code__input--field border-radius-5" name="phone" value="<?php echo e($get_all_address12_phone); ?>" /> </p>


    <p> Address : <input type="text" class="checkout__discount--code__input--field border-radius-5" name="address" value="<?php echo e($get_all_address12_address); ?>" /> </p>

    <p> Town : <input type="text" class="checkout__discount--code__input--field border-radius-5" name="town" value="<?php echo e($get_all_address12_town); ?>" /> </p>


<button type="submit" class="btn btn-primary"> Update</button>

</form>


<hr>


<?php
                        $recent_odrder_list = DB::table('invoices')->where('client_slug',Auth::user()->id)->latest()->get();

                        ?>
                            <h2 class="account__content--title h3 mb-20">Orders History</h2>
                            <div class="account__table--area">
                                <table class="account__table">
                                    <thead class="account__table--header">
                                        <tr class="account__table--header__child">
                                            <th class="account__table--header__child--items">Order</th>
                                            <th class="account__table--header__child--items">Date</th>
                                            <th class="account__table--header__child--items">Payment Status</th>
                                            <th class="account__table--header__child--items">Fulfillment Status</th>
                                            <th class="account__table--header__child--items">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody class="account__table--body mobile__none">

                                    <?php $__currentLoopData = $recent_odrder_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_recent_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="account__table--body__child">
                                            <td class="account__table--body__child--items">#<?php echo e($all_recent_list->order_id); ?></td>
                                            <td class="account__table--body__child--items"><?php echo e(\Carbon\Carbon::parse($all_recent_list->created_at)->format('d M Y')); ?></td>
                                            <td class="account__table--body__child--items">

                                             <?php if($all_recent_list->due == 0 ): ?>

                                            Paid
                                            <?php else: ?>
 UnPaid
                                            <?php endif; ?>

                                            </td>
                                            <td class="account__table--body__child--items">


                                <?php if(empty($all_recent_list->delivery_status) ): ?>
                                Processing

                            <?php else: ?>
                            <?php echo e($all_recent_list->delivery_status); ?>




                            <?php endif; ?>




                                            </td>
                                            <td class="account__table--body__child--items"><?php echo e($all_recent_list->grand_total); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                    <tbody class="account__table--body mobile__block">
                                           <?php $__currentLoopData = $recent_odrder_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_recent_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="account__table--body__child">
                                            <td class="account__table--body__child--items">
                                                <strong>Order</strong>
                                                <span>#<?php echo e($all_recent_list->order_id); ?></span>
                                            </td>
                                            <td class="account__table--body__child--items">
                                                <strong>Date</strong>
                                                <span><?php echo e(\Carbon\Carbon::parse($all_recent_list->created_at)->format('d M Y')); ?></span>
                                            </td>
                                            <td class="account__table--body__child--items">
                                                <strong>Payment Status</strong>
                                                <span>  <?php if($all_recent_list->due == 0 ): ?>

                                            Paid
                                            <?php else: ?>
 UnPaid
                                            <?php endif; ?></span>
                                            </td>
                                            <td class="account__table--body__child--items">
                                                <strong>Fulfillment Status</strong>
                                                <span>
    ?>
                                <?php if(empty($all_recent_list->delivery_status) ): ?>
                                Processing

                            <?php else: ?>
                            <?php echo e($all_recent_list->delivery_status); ?>




                            <?php endif; ?></span>
                                            </td>
                                            <td class="account__table--body__child--items">
                                                <strong>Total</strong>
                                                <span><?php echo e($all_recent_list->grand_total); ?></span>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- my account section end -->

        <!-- Start shipping section -->
        <section class="shipping__section2 shipping__style3 section--padding pt-0">
            <div class="container">
                <div class="shipping__section2--inner shipping__style3--inner d-flex justify-content-between">
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping1.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Shipping</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping2.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Payment</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping3.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Return</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping4.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Support</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End shipping section -->

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project_july_2022\htdocs\2023\moin_code__25_march\resources\views/front/otherPage/customer_dashboard.blade.php ENDPATH**/ ?>