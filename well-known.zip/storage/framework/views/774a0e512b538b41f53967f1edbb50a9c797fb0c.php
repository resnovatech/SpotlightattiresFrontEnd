<div class="header__bottom">
    <div class="container-fluid">
        <div class="header__bottom--inner position__relative d-none d-lg-flex justify-content-between align-items-center">
            <div class="header__menu">
                <nav class="header__menu--navigation">
                    <ul class="d-flex">
                        <li class="header__menu--items">
                            <a class="header__menu--link" href="<?php echo e(route('index')); ?>">Home</a>
                        </li>
                        <li class="header__menu--items mega__menu--items">
                            <a class="header__menu--link" href="#">Shop
                                <svg class="menu__arrowdown--icon" xmlns="http://www.w3.org/2000/svg" width="12" height="7.41" viewBox="0 0 12 7.41">
                                    <path  d="M16.59,8.59,12,13.17,7.41,8.59,6,10l6,6,6-6Z" transform="translate(-6 -8.59)" fill="currentColor" opacity="0.7"/>
                                </svg>
                            </a>
                            <ul class="header__mega--menu d-flex">

                                <?php $__currentLoopData = $get_all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_get_all_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php

                     $sub_cat_list = DB::table('categories')
                     ->where('cat_name',$all_get_all_category->cat_name)
                     ->whereNotNull('sub_cat')
                     ->select('sub_cat')->distinct()->latest()->get();
                        ?>

                                <li class="header__mega--menu__li">
                                    <span class="header__mega--subtitle"><a href="<?php echo e(route('categoryProduct',$all_get_all_category->cat_name)); ?>">
                                        <?php echo e($all_get_all_category->cat_name); ?>

                                    </a></span>
                                    <ul class="header__mega--sub__menu">
                                        <?php $__currentLoopData = $sub_cat_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_sub_cat_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="header__mega--sub__menu_li"><a class="header__mega--sub__menu--title" href="<?php echo e(route('categoryProduct',$all_sub_cat_list->sub_cat)); ?>"><?php echo e($all_sub_cat_list->sub_cat); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </li>
                        <li class="header__menu--items">
                            <a class="header__menu--link" href="<?php echo e(route('about_us_new')); ?>">About US </a>
                        </li>
                        <li class="header__menu--items">
                            <a class="header__menu--link" href="<?php echo e(route('blog_new')); ?>">Blog</a>
                        </li>
                        <li class="header__menu--items d-none d-xl-block">
                            <a class="header__menu--link" href="<?php echo e(route('animationCategoryProductList')); ?>">Anim Character </a>
                        </li>
                        <li class="header__menu--items">
                            <a class="header__menu--link" href="<?php echo e(route('contact_us_new')); ?>">Contact </a>
                        </li>
                    </ul>
                </nav>
            </div>
            <p class="header__discount--text"><img class="header__discount--icon__img" src="<?php echo e(asset('/')); ?>public/front/assets/img/icon/lamp.png" alt="lamp-img"><?php echo e($offer_title); ?></p>
        </div>
    </div>
</div>
<?php /**PATH E:\project_july_2022\htdocs\2023\new_ecommerce_march\resources\views/front/include/header_bottom.blade.php ENDPATH**/ ?>