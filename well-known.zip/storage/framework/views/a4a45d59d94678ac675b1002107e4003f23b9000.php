<!-- Quickview Wrapper -->
<div class="modal" id="modal1" data-animation="slideInUp">
    <div class="modal-dialog quickview__main--wrapper">
        <header class="modal-header quickview__header">
            <button class="close-modal quickview__close--btn" aria-label="close modal" data-close>✕ </button>
        </header>
        <div class="quickview__inner"  >
            <div class="row row-cols-lg-2 row-cols-md-2">
                <div class="col">
                    <div class="quickview__product--media product__details--media"  >
                        <div class="product__media--preview  swiper">
                            <div class="swiper-wrapper" id="main_content_table">
                                

                            </div>
                        </div>
                        <div class="product__media--nav swiper">
                            <div class="swiper-wrapper">


                            </div>
                            <div class="swiper__nav--btn swiper-button-next"></div>
                            <div class="swiper__nav--btn swiper-button-prev"></div>
                        </div>
                    </div>
                </div>
                <form method="post" action="<?php echo e(route('add_to_card_from_quick_view')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="col">
                    <div class="quickview__info">
                        <input type="hidden" id="product_id_quickview" name="product_id" />

                            <h2 class="product__details--info__title mb-15" id="product_name">Oversize Cotton Dress</h2>
                            <div class="product__details--info__price mb-10">
                                <span class="current__price" id="product_price">$58.00</span>

                            </div>

                            <p class="product__details--info__desc mb-15" id="product_detail">Lorem ipsum dolor sit amet, consectetur adipisicing elit is. Deserunt totam dolores ea numquam labore! Illum magnam totam tenetur fuga quo dolor.</p>
                            <div class="product__variant">
                                <div class="product__variant--list mb-10">
                                    <fieldset class="variant__input--fieldset" id="main_content_table1">

                                    </fieldset>
                                </div>




                                <div class="product__variant--list mb-15">
                                    <fieldset class="variant__input--fieldset weight" id="main_content_table2">

                                    </fieldset>
                                </div>

                                <div class="product__variant--list mb-10">
                                    <fieldset class="variant__input--fieldset" id="main_content_table3">

                                    </fieldset>
                                </div>



                                <div class="quickview__variant--list quantity d-flex align-items-center mb-15">
                                    
                                    <button class="primary__btn quickview__cart--btn" id="quick_view_add_to_card" type="submit" >Add To Cart</button>
                                </div>

                            </div>


                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
<!-- Quickview Wrapper End -->
<?php /**PATH /home/nirrtjiu/demo.spotlightattires.com/resources/views/front/include/product_quickview.blade.php ENDPATH**/ ?>