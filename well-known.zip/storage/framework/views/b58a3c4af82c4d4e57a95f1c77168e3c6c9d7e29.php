



<?php /**PATH E:\project_july_2022\htdocs\2023\new_ecommerce_march\resources\views/front/productPages/quick_view_data3.blade.php ENDPATH**/ ?>