

<div class="minicart__product">

    <?php  $totalProductPrice = 0; ?>
    <?php $__currentLoopData = $cartCollection1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="minicart__product--items d-flex">
        <div class="minicart__thumb">
            <a href="#"><img src="<?php echo e($url_name); ?><?php echo e($item->attributes->image); ?>" alt="prduct-img"></a>
        </div>
        <div class="minicart__text">
            <h3 class="minicart__subtitle h4"><a href="#"><?php echo e($item->name); ?></a></h3>
            <?php if($item->attributes->color == 0): ?>

            <?php else: ?>
            <span class="color__variant"><b>Color:</b> <?php echo e($item->attributes->color); ?></span>
            <?php endif; ?>


            <?php if($item->attributes->size == 0): ?>

            <?php else: ?>
            <span class="color__variant"><b>Size:</b> <?php echo e($item->attributes->size); ?></span>
            <?php endif; ?>



            <div class="minicart__price">
                <span class="current__price">৳ <?php echo e($item->price); ?></span>
                
            </div>
            <div class="minicart__text--footer d-flex align-items-center">
                <div class="quantity__box minicart__quantity">
                    <button type="button"  class="quantity__value " id="dcrease_data_from_side_bar<?php echo e($item->id); ?>" aria-label="quantity value" value="Decrease Value">-</button>
                    <label>
                        <input type="number" class="quantity__number" value="<?php echo e($item->quantity); ?>" id="sidebarQuantity<?php echo e($item->id); ?>" />
                    </label>
                    <button type="button" class="quantity__value " id="increase_data_from_side_bar<?php echo e($item->id); ?>"  value="Increase Value">+</button> 
                </div>
                
            </div>
        </div>
    </div>

    <?php $totalProductPrice = $totalProductPrice  +  ($item->price*$item->quantity)  ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="minicart__amount">
    
    <div class="minicart__amount_list d-flex justify-content-between">
        <span>Total:</span>
        <span><b> ৳ <?php echo e($totalProductPrice); ?></b></span>
    </div>
</div>

<div class="minicart__button d-flex justify-content-center mt-4">
    <a class="primary__btn minicart__button--link" href="<?php echo e(route('cart')); ?>">View cart</a>
    <a class="primary__btn minicart__button--link" href="<?php echo e(route('check_out_from_cart')); ?>">Checkout</a>
</div>

 <script>
    $(document).ready(function(){
          $("[id^=increase_data_from_side_bar]").click(function(){
              
              
                var currentId  = $(this).attr('id');
                var after_string_slice_id = currentId.slice(27);
                
                 var previous_cart_quantity  = parseInt($('#main_cart_count1').html());
                 
                 var get_main_value = parseInt(previous_cart_quantity+1);
                 
                 var main_quantity = $('#sidebarQuantity'+after_string_slice_id).val()
                 
                 var final_quantity = parseInt(main_quantity+1);
                
                //alert(main_quantity);
                
                $('#main_cart_count1').html(get_main_value);
                $('#main_cart_count2').html(get_main_value);
               $('#main_cart_count3').html(get_main_value);
               
                  $.ajax({
url: "<?php echo e(route('add_to_card_all_product')); ?>",
type: "GET",
data: {
'after_string_slice_id': after_string_slice_id
},
success: function (data) {

$("#main_sidebar").html('');
$('#main_sidebar').html(data);

alertify.set('notifier','position', 'top-center');
    alertify.success('Added To Cart!');

}

});

               
               
               
              
          });
          
          ///////
          
           $("[id^=dcrease_data_from_side_bar]").click(function(){
              
              
                var currentId  = $(this).attr('id');
                var after_string_slice_id = currentId.slice(26);
                
                //alert(after_string_slice_id);
                
                  var previous_cart_quantity  = parseInt($('#main_cart_count1').html());
                 
                 var get_main_value = parseInt(previous_cart_quantity-1);
                
           
                 
                 
                
               var main_quantity = $('#sidebarQuantity'+after_string_slice_id).val()
                 
                 var final_quantity = parseInt(main_quantity-1);
                 
                 //alert(final_quantity);
                
            $('#main_cart_count1').html(get_main_value);
            $('#main_cart_count2').html(get_main_value);
            $('#main_cart_count3').html(get_main_value);
            
            if(final_quantity == 0){
                
                               $.ajax({
url: "<?php echo e(route('delete_from_sidebar_new')); ?>",
type: "GET",
data: {
'after_string_slice_id': after_string_slice_id
},
success: function (data) {

$("#main_sidebar").html('');
$('#main_sidebar').html(data);

alertify.set('notifier','position', 'top-center');
    alertify.success('Delete From Cart!');

}

});
                
            }else{
                               $.ajax({
url: "<?php echo e(route('dcrease_data_from_side_bar')); ?>",
type: "GET",
data: {
'after_string_slice_id': after_string_slice_id,'final_quantity':final_quantity
},
success: function (data) {

$("#main_sidebar").html('');
$('#main_sidebar').html(data);

alertify.set('notifier','position', 'top-center');
    alertify.success('Remove From Cart!');

}

});
                
            }
              
              
          });
  
    });
    </script>
<?php /**PATH /home/nirrtjiu/demo.resnova.dev/resources/views/front/cartPage/add_to_card_all_product.blade.php ENDPATH**/ ?>