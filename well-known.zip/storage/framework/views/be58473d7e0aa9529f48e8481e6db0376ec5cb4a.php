



                            <legend class="product__variant--title mb-8">Size :</legend>
                            <?php $__currentLoopData = $assaign_color_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$all_assaign_size_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if(($key+1) == 1): ?>
                            <input id="weight<?php echo e($key+1); ?>" name="weight" type="radio" value="<?php echo e($all_assaign_size_all->size_name); ?>" checked>
                            <label class="variant__size--value red" for="weight<?php echo e($key+1); ?>"><?php echo e($all_assaign_size_all->size_name); ?></label>
                            <?php else: ?>

                            <input id="weight<?php echo e($key+1); ?>" name="weight" type="radio" value="<?php echo e($all_assaign_size_all->size_name); ?>" >
                            <label class="variant__size--value red" for="weight<?php echo e($key+1); ?>"><?php echo e($all_assaign_size_all->size_name); ?></label>

                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH /home/nirrtjiu/demo.spotlightattires.com/resources/views/front/productPages/quick_view_data2.blade.php ENDPATH**/ ?>