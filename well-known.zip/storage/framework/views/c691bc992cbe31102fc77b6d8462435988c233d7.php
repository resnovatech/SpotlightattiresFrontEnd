<div id="preloader">
    <div id="ctn-preloader" class="ctn-preloader">
        <div class="animation-preloader">
            <div class="spinner"></div>
            <div class="txt-loading">
                <span data-text-preloader="S" class="letters-loading">
                        S
                </span>

                <span data-text-preloader="P" class="letters-loading">
                        P
                </span>

                <span data-text-preloader="O" class="letters-loading">
                        O
                </span>

                <span data-text-preloader="A" class="letters-loading">
                        A
                </span>

                <span data-text-preloader="T" class="letters-loading">
                        T
                </span>

                <span data-text-preloader="L" class="letters-loading">
                        L
                </span>

                <span data-text-preloader="I" class="letters-loading">
                        I
                </span>

                <span data-text-preloader="G" class="letters-loading">
                        G
                </span>

                <span data-text-preloader="H" class="letters-loading">
                        H
                </span>

                <span data-text-preloader="T" class="letters-loading">
                        T
                </span>

                <span data-text-preloader=" " class="letters-loading">

                </span>

                <span data-text-preloader="A" class="letters-loading">
                        A
                </span>

                <span data-text-preloader="T" class="letters-loading">
                        T
                </span>

                <span data-text-preloader="T" class="letters-loading">
                        T
                </span>

                <span data-text-preloader="I" class="letters-loading">
                        I
                </span>

                <span data-text-preloader="R" class="letters-loading">
                        R
                </span>

                <span data-text-preloader="E" class="letters-loading">
                        E
                </span>

                <span data-text-preloader="S" class="letters-loading">
                        S
                </span>

                <br>

                <div class="pt-4">
                                <span data-text-preloader="L" class="letters-loading">
                        L
                    </span>

                    <span data-text-preloader="O" class="letters-loading">
                        O
                    </span>

                    <span data-text-preloader="A" class="letters-loading">
                        A
                    </span>

                    <span data-text-preloader="D" class="letters-loading">
                        D
                    </span>

                    <span data-text-preloader="I" class="letters-loading">
                        I
                    </span>

                    <span data-text-preloader="N" class="letters-loading">
                        N
                    </span>

                    <span data-text-preloader="G" class="letters-loading">
                        G
                    </span>
                </div>

            </div>
        </div>
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>
</div>
<?php /**PATH /home/nirrtjiu/demo.resnova.dev/resources/views/front/include/load.blade.php ENDPATH**/ ?>