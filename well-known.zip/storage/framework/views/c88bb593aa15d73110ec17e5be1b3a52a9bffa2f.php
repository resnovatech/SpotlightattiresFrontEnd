<h1>Email Verification</h1>
Click the link :
<a href="<?php echo e(route('user.verify', $token)); ?>">Click Here</a>
<?php /**PATH E:\project_july_2022\htdocs\2023\moin_code__25_march\resources\views/emails/emailVerificationEmail.blade.php ENDPATH**/ ?>