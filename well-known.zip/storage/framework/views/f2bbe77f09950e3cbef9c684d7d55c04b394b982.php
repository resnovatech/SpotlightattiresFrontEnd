<?php $__env->startSection('title'); ?>

Login Page

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
<main class="main__content_wrapper">

        <!-- Start breadcrumb section -->
        
        <!-- End breadcrumb section -->

        <!-- Start login section  -->
        <div class="login__section section--padding">
            <div class="container">

                    <div class="login__section--inner">
                        <div class="row row-cols-md-2 row-cols-1">
                            <div class="col">
                                <div class="account__login">
                                    <div class="account__login--header mb-25">
                                        <h2 class="account__login--header__title h3 mb-10">Login</h2>
                                        <p class="account__login--header__desc">Login if you area a returning customer.</p>
                                    </div>
                                    <div class="account__login--inner">
                                    <form action="<?php echo e(route('post_review_login')); ?>" method="post">
                <?php echo csrf_field(); ?>

                                        <input class="account__login--input" placeholder="Email Addres" name="email1"  type="text">
                                        <input class="account__login--input" placeholder="Password" name="pass" type="password">
                                        <div class="account__login--remember__forgot mb-15 d-flex justify-content-between align-items-center">
                                            <div class="account__login--remember position__relative">
                                                <input class="checkout__checkbox--input" id="check1" type="checkbox">
                                                <span class="checkout__checkbox--checkmark"></span>
                                                <label class="checkout__checkbox--label login__remember--label" for="check1">
                                                    Remember me</label>
                                            </div>
                                            
                                        </div>
                                        <input name="b_value" value="Login" class="account__login--btn primary__btn" type="submit"/>


                                        
</form>

                                    </div>
                                </div>
                            </div>
                            <div class="col">
                                <div class="account__login register">
                                    <div class="account__login--header mb-25">
                                        <h2 class="account__login--header__title h3 mb-10">Create an Account</h2>
                                        <p class="account__login--header__desc">Register here if you are a new customer</p>
                                    </div>

                                    <div class="account__login--inner">
                                        <form action="<?php echo e(route('customer_reg_post_dash')); ?>" method="post">
                                            <?php echo csrf_field(); ?>

                                        <input class="account__login--input" placeholder="Username" name="name" type="text">
                                        <input class="account__login--input" placeholder="Email Address" name="email"  type="text">

                                        <input class="account__login--input" placeholder="Phone" name="phone"  type="text">


                                        <input class="account__login--input" placeholder="Password" name="pass" type="password">

                                        <input name="b_value" class="account__login--btn primary__btn mb-10" value="Register" type="submit"/>
                                        
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
        <!-- End login section  -->

        <!-- Start shipping section -->
        <section class="shipping__section2 shipping__style3 section--padding pt-0">
            <div class="container">
                <div class="shipping__section2--inner shipping__style3--inner d-flex justify-content-between">
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping1.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Shipping</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping2.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Payment</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping3.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Return</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                    <div class="shipping__items2 d-flex align-items-center">
                        <div class="shipping__items2--icon">
                            <img src="<?php echo e(asset('/')); ?>public/front/assets/img/other/shipping4.png" alt="">
                        </div>
                        <div class="shipping__items2--content">
                            <h2 class="shipping__items2--content__title h3">Support</h2>
                            <p class="shipping__items2--content__desc">From handpicked sellers</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End shipping section -->

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nirrtjiu/demo.spotlightattires.com/resources/views/front/otherPage/review_login.blade.php ENDPATH**/ ?>