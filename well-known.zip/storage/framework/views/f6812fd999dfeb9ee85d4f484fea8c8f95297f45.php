<section class="hero__slider--section">
    <div class="hero__slider--inner hero__slider--activation swiper">
        <div class="hero__slider--wrapper swiper-wrapper">


            <?php $__currentLoopData = $banner_first_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$all_banner_first_lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide ">
                <?php if(($key+1) == 1): ?>

                <div class="hero__slider--items home1__slider--bg" style="background:url('<?php echo e($url_name); ?><?php echo e($all_banner_first_lists->image); ?>');background-repeat: no-repeat;
                    background-size: 100% 100%;">

<?php elseif(($key+1) == 2): ?>
<div class="hero__slider--items home1__slider--bg two" style="background:url('<?php echo e($url_name); ?><?php echo e($all_banner_first_lists->image); ?>');background-repeat: no-repeat;
    background-size: 100% 100%;">

<?php else: ?>
<div class="hero__slider--items home1__slider--bg three" style="background:url('<?php echo e($url_name); ?><?php echo e($all_banner_first_lists->image); ?>');background-repeat: no-repeat;
    background-size: 100% 100%;">
<?php endif; ?>
                    <div class="container-fluid">
                        <div class="hero__slider--items__inner">
                            <div class="row row-cols-1">
                                <div class="col">
                                    <div class="slider__content">
                                        <p class="slider__content--desc desc1 mb-15"><img class="slider__text--shape__icon" src="<?php echo e(asset('/')); ?>public/front/assets/img/icon/text-shape-icon.png" alt="text-shape-icon"><?php echo e($all_banner_first_lists->first_title); ?></p>
                                        <h2 class="slider__content--maintitle h1"><?php echo e($all_banner_first_lists->second_title); ?><br>
                                            <?php echo e($all_banner_first_lists->four_title); ?></h2>
                                        <p class="slider__content--desc desc2 d-sm-2-none mb-40"><?php echo e($all_banner_first_lists->third_title); ?></p>
                                        <a class="slider__btn primary__btn" href="<?php echo e(route('animationCategory',$all_banner_first_lists->button_link)); ?>"><?php echo e($all_banner_first_lists->button_name); ?>

                                            <svg class="primary__btn--arrow__icon" xmlns="http://www.w3.org/2000/svg" width="20.2" height="12.2" viewBox="0 0 6.2 6.2">
                                                <path d="M7.1,4l-.546.546L8.716,6.713H4v.775H8.716L6.554,9.654,7.1,10.2,9.233,8.067,10.2,7.1Z" transform="translate(-4 -4)" fill="currentColor"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
        <div class="swiper__nav--btn swiper-button-next"></div>
        <div class="swiper__nav--btn swiper-button-prev"></div>
    </div>
</section>
<?php /**PATH E:\project_july_2022\htdocs\2023\moin_code__25_march\resources\views/front/include/banner.blade.php ENDPATH**/ ?>